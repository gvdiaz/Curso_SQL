# Descripción: Ejercicio 3.7
# Autor: Gustavo Vladimir Diaz
# Fecha: 25/09/2020
# Enunciado: 
# Obtener la lista de los cuits de las facturas a partir de la vista generada en el ejercicio práctico 3.5
#
# Objetivo de ejercicio: generar vista de un CUIT, IdFactura y el total de la factura

# Desarrollo

SELECT CUIT FROM prueba_cliente_eje_3_5.fact_clientes;