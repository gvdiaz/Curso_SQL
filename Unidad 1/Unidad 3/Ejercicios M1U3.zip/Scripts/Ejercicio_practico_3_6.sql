# Descripción: Ejercicio 3.6
# Autor: Gustavo Vladimir Diaz
# Fecha: 25/09/2020
# Enunciado: 
# Utilizar la vista generada en el ejercicio 3.4 (Lo hago del ejercicio 3.5 porque no existe tal tabla del ejercicio 3.4)
#
# Objetivo de ejercicio: generar vista de un CUIT, IdFactura y el total de la factura

# Desarrollo
# Nota: Antes de ejecutar esta sentencia debería ejecutar el script "Ejercicio_practico_3_5.sql" hasta antes de las sentencias DROP.
SELECT * FROM prueba_cliente_eje_3_5.fact_clientes;