# Descripción: Ejercicio 3.8
# Autor: Gustavo Vladimir Diaz
# Fecha: 25/09/2020
# Enunciado: 
# Escribir las sentencias que eliminan las vistas generadas en los ejercicios prácticos 3.4 y 3.5
#
# Objetivo de ejercicio: generar vista de un CUIT, IdFactura y el total de la factura

# Desarrollo
DROP VIEW fact_clientes;
