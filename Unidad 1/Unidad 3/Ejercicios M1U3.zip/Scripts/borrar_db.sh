#!/bin/bash
mysql -u "root" -p -e "DROP DATABASE $1";
